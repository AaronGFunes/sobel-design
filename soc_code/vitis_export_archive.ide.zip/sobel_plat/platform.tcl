# 
# Usage: To re-create this platform project launch xsct with below options.
# xsct C:\Users\aaron\Documents\School\fall_26\ece_698c\sobel-design-2\sobel_soc\sobel_soc_vitis\sobel_app\sobel_plat\platform.tcl
# 
# OR launch xsct and run below command.
# source C:\Users\aaron\Documents\School\fall_26\ece_698c\sobel-design-2\sobel_soc\sobel_soc_vitis\sobel_app\sobel_plat\platform.tcl
# 
# To create the platform in a different location, modify the -out option of "platform create" command.
# -out option specifies the output directory of the platform project.

platform create -name {sobel_plat}\
-hw {C:\Users\aaron\Documents\School\fall_26\ece_698c\sobel-design-2\sobel_soc\sobel_bd_wrapper.xsa}\
-proc {ps7_cortexa9_0} -os {standalone} -out {C:/Users/aaron/Documents/School/fall_26/ece_698c/sobel-design-2/sobel_soc/sobel_soc_vitis/sobel_app}

platform write
platform generate -domains 
platform active {sobel_plat}
domain active {zynq_fsbl}
bsp reload
bsp setdriver -ip sobel_ip_0 -driver none -ver {}
bsp write
bsp reload
catch {bsp regenerate}
bsp reload
domain active {standalone_domain}
bsp reload
bsp setlib -name xilffs -ver 5.2
bsp setdriver -ip sobel_ip_0 -driver none -ver {}
bsp write
bsp reload
catch {bsp regenerate}
platform generate
domain active {zynq_fsbl}
bsp reload
